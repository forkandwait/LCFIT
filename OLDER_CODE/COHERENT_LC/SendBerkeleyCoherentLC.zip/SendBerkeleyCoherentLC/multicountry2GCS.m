
function [eoh,eof,drft,sdgkt,a0,a1,sdckt]=multicountry2GCS(Bx,Kt,mx,rndgk,nfor,ntrj,nfor5,nspt);
%This code does non-divergent LC forecast, including:
xxx=size(mx);nht=xxx(1);
%Caole-Guo
    for i=1:nht
        for j=1:18;
       drt(j)=mx(i,j);
        end     
        mxt(i,:)=CoaleGt(drt);
        eoh(i)=lfexpt(mxt(i,:));
    end
          
%mxt--matrix of ASDR,
%nffy--first year of forecasting,
%nfor--number of time to be forecasted,
%nfor--number of time to be forecasted in 5-yr interval,
%nspt--different bewteen first year of forscast in 5-yr and the last hist data 
%ntrj--number of trajectories,

xxx=size(mxt);nag=xxx(2);
                    
%(2)SVD 
 %(1.1)make matrix for SVD
lnmx = log(mxt);ax= mean(lnmx);
for ix = 1:nht,
    for j=1:nag
   lnmx1(ix,j) = lnmx(ix,j)-ax(j)-Bx(j)*Kt(ix);
   end
end
% SVD, where bx is sum to 1
[U S V] = svd(lnmx1,0);bx = V(:,1)/sum(V(:,1));kt= S(1,1)*U(:,1)*sum(V(:,1));
%End (2)
      
%(4) Estimating drift and sdgkt for the RWD of group
dKt=diff(Kt);drft=mean(dKt); sdgkt=sqrt(cov(dKt));
%End (4)

%(5) Estimating a0,a1 and sdckt for the AR(1)-->k(t)=a0+a1*k(t-1)+sdckt*e(t) of a country.
for i=1:nht-1
    X(i,2)=kt(i);X(i,1)=1;y(i)=kt(i+1);    
end
%OLS
b(1)=sum(y);b(2)=y*X(:,2);
a(1,1)=nht-1;a(1,2)=sum(X(:,2));a(2,1)=a(1,2);a(2,2)=X(:,2)'*X(:,2);
xxx=(a^-1)*b';
a0=xxx(1);a1=xxx(2);a00=mean(y);
ktm(1)=kt(1);
      for i=2:nht
          ktm(i)=a0+a1*ktm(i-1);
       end
       for i=1:nht    
       e(i)=kt(i)-ktm(i);   
       e0(i)=kt(i)-mean(kt);
       end
       sdckt=sqrt(cov(e));
       Rsq=1-cov(e)/cov(e0);%R^2
       %Estimating SDT of a0 and a1
       sda0=sdckt/sqrt((nht-1));sda1=sdckt/sqrt((kt'*kt));              
%End (5)


%(6)Forcsting
%End (6.1)
randn('state',1);rndgc=randn(ntrj,nfor); 
randn('state',2);rndgce=randn(ntrj,nfor);%estimating errors are independent to ...
%randn('state',2);rndgce=randn(ntrj,1);
% (6.2) Generate stochastic trajectories of Kt and ktc:
  stokg=zeros(ntrj,nfor+1);stokg(:,1)=Kt(nht);%Group Kt, RWD
  stokc=zeros(ntrj,nfor+1);stokc(:,1)=kt(nht);
for tind =1:ntrj,
   for yind0=1:nfor,%Single yr forecast for handle AR(1) simplier
      stokg(tind,yind0+1)=stokg(tind,1)+yind0*drft+(yind0+yind0^2/nht)^.5*sdgkt*rndgk(tind,yind0);%RWD
      zzz=(a0+sda0*rndgce(tind,yind0))+(a1+sda1*rndgce(tind,yind0))*stokc(tind,yind0);
      %zzz=(a0+sda0*rndgce(tind))+(a1+sda1*rndgce(tind))*stokc(tind,yind0);
      stokc(tind,yind0+1)=zzz+sdckt*rndgc(tind,yind0);   
   end
end
%End(6.2)
%(6.3)mx
mxf=zeros(ntrj,nfor5,nag);
for tt=1:nfor5
   tto=nspt+5*(tt-1);
 for tind=1:ntrj
    for j=1:nag   
    mxf(tind,tt,j)=mxt(nht,j)*exp((stokg(tind,tto)-stokg(tind,1))*Bx(j)+(stokc(tind,tto)-stokc(tind,1))*bx(j));    
    end
           if mxf(tind,tt,1)>0.78;mxf(tind,tt,1)=0.78;end;%keep q<1
           if mxf(tind,tt,2)>0.66;mxf(tind,tt,2)=0.66;end;
           for i=3:3;if mxf(tind,tt,i)>0.4;mxf(tind,tt,i)=0.39;end;end;
 end
end
%End(6.3)
%(7) Forecasted Eo  
[e9750,e500,e250]=pictG(mxf);%kt
eof(1,:)=e9750;eof(2,:)=e500;eof(3,:)=e250;


