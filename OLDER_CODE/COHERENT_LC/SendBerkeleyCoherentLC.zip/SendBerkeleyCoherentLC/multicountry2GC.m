
function [eoh,eof,drft,sdgkt]=multicountry2GC(Bx,Kt,mx,rndgk,nfor,ntrj,nfor5,nspt)

%This code does non-divergent LC forecast, including:
xxx=size(mx);nht=xxx(1);
%Caole-Guo
    for i=1:nht
        for j=1:18;
       drt(j)=mx(i,j);
        end     
        mxt(i,:)=CoaleGt(drt);
        eoh(i)=lfexpt(mxt(i,:));
    end
          
%mxt--matrix of ASDR,
%nffy--first year of forecasting,
%nfor--number of time to be forecasted,
%nfor--number of time to be forecasted in 5-yr interval,
%nspt--different bewteen first year of forscast in 5-yr and the last hist data 
%ntrj--number of trajectories,

xxx=size(mxt);nag=xxx(2);

%(4) Estimating drift and sdgkt for the RWD of group
dKt=diff(Kt);drft=mean(dKt); sdgkt=sqrt(cov(dKt));
%End (4)


%(6)Forcsting
%End (6.1)
  % (6.2) Generate stochastic trajectories of Kt and ktc:
stokg=zeros(ntrj,nfor+1);stokg(:,1)=Kt(nht);%Group Kt, RWD
for tind =1:ntrj,
   for yind0=1:nfor,%Single yr forecast for handle AR(1) simplier
      stokg(tind,yind0+1)=stokg(tind,1)+yind0*drft+(yind0+yind0^2/nht)^.5*sdgkt*rndgk(tind,yind0);%RWD
   end
end
%End(6.2)

% (6.3)mx --in 5-yr; save time!
mxf=zeros(ntrj,nfor5,nag);
for tt=1:nfor5
   tto=nspt+5*(tt-1);
 for tind=1:ntrj
    for j=1:nag   
    mxf(tind,tt,j)=mxt(nht,j)*exp((stokg(tind,tto)-stokg(tind,1))*Bx(j));    
    end
           if mxf(tind,tt,1)>0.78;mxf(tind,tt,1)=0.78;end;%keep q<1
           if mxf(tind,tt,2)>0.66;mxf(tind,tt,2)=0.66;end;
           for i=3:3;if mxf(tind,tt,i)>0.4;mxf(tind,tt,i)=0.39;end;end;
 end
end
%End (6.3)

%End(6)

%(7) Forecasted Eo  
[e9750,e500,e250]=pictG(mxf);%kt
eof(1,:)=e9750;eof(2,:)=e500;eof(3,:)=e250;

%mxo(1:ntrj)=mxf(:,nfor5,1);mean(mxo)
%Male ASDR(0) at 2100,1.0372e-004
%Female ASDR(0) at 2100,8.9978e-005
%Ratio of M/F=1.15
%Male ASDR(0) at 2002,0.0036
%Female ASDR(0) at 2002,0.0031
%Ratio of M/F=1.16


%Male ASDR(40-44) at 2002,0.0015
%Female ASDR(40-44) at 2002,8.7100e-004
%Ratio of M/F =1.72


