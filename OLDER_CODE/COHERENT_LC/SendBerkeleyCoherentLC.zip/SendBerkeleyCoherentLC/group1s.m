

%(I)Get mxc, Bx and Kt, and country-specific kt for the G7
clear
load c:\users\linan\surrey04\multicountry1\data\sweden\BXKT; %get common factor
nfor=100;%Number of 1-yr intervals of forecasting
ntrj=500;%Number of trajectories
randn('state',10);%To be indep. 
rndgk=randn(ntrj,nfor); %Random var for modelling group Kt, 1-yr
nfor5=20;%5-yr
nffy5=2005;
nspt=3;%2002+3=2005
nht=53;

drift=mean(diff(Kt));%Get R^2 for RW
Ktm(1)=Kt(1);
for i=2:nht
    Ktm(i)=Kt(i-1)+drift;
end
RKt=1-var(Kt-Ktm)/var(Kt);


load c:\users\linan\surrey04\multicountry1\data\sweden\mxm5002.txt;
load c:\users\linan\surrey04\multicountry1\data\sweden\mxf5002.txt;
load c:\users\linan\surrey04\multicountry1\data\sweden\pxm5002.txt;
load c:\users\linan\surrey04\multicountry1\data\sweden\pxf5002.txt;
%Male(C)
ic=1
mx=mxm5002;
[eoh,eof,drft,sdgkt]=multicountry2GC(Bx,Kt,mx,rndgk,nfor,ntrj,nfor5,nspt);%2MIN
Eoh(ic,:)=eoh;Eof(ic,1:3,1:nfor5)=eof;
eoh(nht)%eo(2002)=77.7950
eof(2,nfor5)%eo(2010)=89.7131
eof(1,nfor5)-eof(3,nfor5)%%95CI(2010)=6.7308
nhly=2002;
[eofs]=multicountry2S(mx,nhly,nffy5,nfor5,ntrj);%Separate forecast
Eofs(ic,1:3,1:nfor5)=eofs;
eofs(2,nfor5)%eo(2010)=86.8288
eofs(1,nfor5)-eofs(3,nfor5)%95CI(2010)=6.5419

%female(CS)
ic=2
mx=mxf5002;
[eoh,eof,drft,sdgkt]=multicountry2GC(Bx,Kt,mx,rndgk,nfor,ntrj,nfor5,nspt);%2MIN
Eoh(ic,:)=eoh;Eof(ic,1:3,1:nfor5)=eof;
eoh(nht)%eo(2002)=82.2286
eof(2,nfor5)%eo(2010)=92.7059
eof(1,nfor5)-eof(3,nfor5)%95CI(2010)=5.7455
nhly=2002;
[eofs]=multicountry2S(mx,nhly,nffy5,nfor5,ntrj);%Separate forecast
Eofs(ic,1:3,1:nfor5)=eofs;
eofs(2,nfor5)%eo(2000)=94.3997
eofs(1,nfor5)-eofs(3,nfor5)%95CI(2010)=8.5795

%save c:\users\linan\surrey04\multicountry1\data\sweden\Eohf Eoh Eof Eofs%save results

em=Eoh(1,:);em(nht+1:nht+nfor5)=Eof(1,2,:);ems(1:nfor5)=Eofs(1,2,:);%male
ef=Eoh(2,:);ef(nht+1:nht+nfor5)=Eof(2,2,:);efs(1:nfor5)=Eofs(2,2,:);%female
time(1:nht)=1949+(1:nht);
times(1:nfor5)=2000+5*(1:nfor5);
clf;plot(time,em(1:nht),'k');hold;plot(time,ef(1:nht),'k.-');plot(times,em(nht+1:nht+nfor5),'ko-');plot(times,ems,'k^-');
plot(times,ef(nht+1:nht+nfor5),'ko-');plot(times,efs,'k^-');
%set(gca, 'Ylim', [55 95]);
legend('Historical male','Historical female','Non-divergent forecasts','Separate forecasts')
xlabel('Year','Fontsize',12);ylabel('Observed and median forecast of life expectancy')
title('Figure 1. Non-divergent and separate forecasts of life expectancy, Sweden','Fontsize',12)
%print fig2 -dbitmap
print fig1 -deps%Required by Demography

x=ef-em;mean(x(1:nht))
%Difference of Eo:  2002   2010(Non-dic.) 2010(separate)  
%                   4.4         2.7              7.6


